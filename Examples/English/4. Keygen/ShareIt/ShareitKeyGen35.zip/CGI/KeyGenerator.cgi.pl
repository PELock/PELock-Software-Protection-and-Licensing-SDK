#!/usr/local/bin/perl
#
# Copyright (c) 2001-2006 element 5, (c) 2006 Digital River GmbH

use CGI qw/:standard/;

# check for errors
if ( 1 == 2) {
  # an error has occured

  # set the status code other than 200
  print "Status: 400 Bad Request\n";
  
  # present the error
  print "Content-Type: text/plain\n\n";
  print "BAD_INPUT\n";
  
  # nothing else to do
  exit;
}

# calculate the key

# enter your secret key generation code here
$key = param('REG_NAME');

# present the key

# the key to be presented inline
print "Content-Type: text/plain\n\n";

# if your key is a binary use the following headers instead
# set the mime type
#print "Content-Type: application/octet-stream\n";
# set the filename for the binary key. Replace 'key.bin' by a filename you want
#print "Content-Disposition: filename=key.bin\n\n";

print $key;
